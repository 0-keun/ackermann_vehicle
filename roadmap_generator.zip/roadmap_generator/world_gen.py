#!usr/bin/python3
from lxml import etree as ET

def worldGenerator(grid, w):
    sdf = ET.Element("sdf", version="1.4")

    world = ET.SubElement(sdf, "world", name="road_test")

    # setting up the scene
    scene = ET.SubElement(world, "scene")

    ambient = ET.SubElement(scene, "ambient")
    ambient.text = w.ambient

    sky = ET.SubElement(scene, "sky")
    clouds = ET.SubElement(sky, "clouds")

    speed = ET.SubElement(clouds, "speed")
    speed.text = "5"

    time = ET.SubElement(sky, "time")
    time.text = w.time

    # including models

    init_x = 0
    init_y = 0
    pos = [init_x, init_y, 0.02, 0, 0, 1.57]
    
    for i in range(grid.totalRows):
        for j in range(grid.totalColumns):
            pos[5]=0.0 
            
            if grid.CompleteGrid[i][j] == 1:  # Straight road
                if(i==grid.totalColumns-1):
                    if(grid.CompleteGrid[i-1][j]==2):
                        pos[5]=1.57
                    elif(grid.CompleteGrid[i-1][j]==1):
                        pos[5]=1.57
                elif(i==0):
                    if(grid.CompleteGrid[i+1][j]==2):
                        pos[5]=1.57
                    elif(grid.CompleteGrid[i+1][j]==1):
                        pos[5]=1.57
                else:
                    if(grid.CompleteGrid[i-1][j]==2 or grid.CompleteGrid[i+1][j]==2):
                        pos[5]=1.57
                    elif(grid.CompleteGrid[i-1][j]==1 or grid.CompleteGrid[i+1][j]==1):
                        pos[5]=1.57
                        
                model = ET.SubElement(world, "model", name=f"road_straight_{i}_{j}")
                #model = ET.SubElement(world, "model", name=f"center_line_{i}_{j}")
                include = ET.SubElement(model, "include")
                uri = ET.SubElement(include, "uri")
                uri.text = "model://road_straight"
                #uri.text = "model://center_line"
                pose = ET.SubElement(model, "pose")
                pose.text = f"{pos[0]} {pos[1]} {pos[2]} 0 0 {pos[5]}"
                
                #add curb byside
                model = ET.SubElement(world, "model", name=f"curb_{i}_{j}")
                include = ET.SubElement(model, "include")
                uri = ET.SubElement(include, "uri")
                uri.text = "model://curb"
                pose = ET.SubElement(model, "pose")
                pose.text = f"{pos[0]} {pos[1]} {pos[2]} 0 0 {pos[5]}"

            elif grid.CompleteGrid[i][j] == 2:  # Intersection
                model = ET.SubElement(world, "model", name=f"road_intersection_{i}_{j}")
                include = ET.SubElement(model, "include")
                uri = ET.SubElement(include, "uri")
                uri.text = "model://road_intersection"
                pose = ET.SubElement(model, "pose")
                pose.text = f"{pos[0]} {pos[1]} {pos[2]} 0 0 {pos[5]}"
                
            elif grid.CompleteGrid[i][j] == 0:  # Ground_plane
                model = ET.SubElement(world, "model", name=f"ground_plane_{i}_{j}")
                include = ET.SubElement(model, "include")
                uri = ET.SubElement(include, "uri")
                uri.text = "model://ground_plane"
                pose = ET.SubElement(model, "pose")
                pos[2] = 0.0
                pose.text = f"{pos[0]} {pos[1]} {pos[2]} 0 0 {pos[5]}"
                pos[2] = 0.02
                
            pos[0] += 3  # Move to the next column

        pos[1] -= 3  # Move to the next row (change the sign to positive if necessary)
        pos[0] = init_x  # Reset X for the next row

    include_sun = ET.SubElement(world, "include", name="sun")
    uri_sun = ET.SubElement(include_sun, "uri")
    uri_sun.text = "model://sun"

    tree = ET.ElementTree(sdf)
    tree.write('road.world', pretty_print=True, xml_declaration=True)

